/*
 * Multi-Tasking RTOS Firmware Scheduler
 * Platform : ESP32 (Arduino core, FreeRTOS built in)
 * Sensor   : DHT22 (temperature + humidity)
 * Display  : SSD1306 128x64 OLED (I2C)
 * Alarm    : Buzzer + red LED
 * Inject   : Push button (simulates an emergency on demand)
 *
 * Tasks (higher number = higher priority)
 *   AlarmTask   prio 3  event driven (task notification) -> instant response
 *   SensorTask  prio 2  periodic 500 ms  (vTaskDelayUntil)
 *   DisplayTask prio 1  periodic 1000 ms (vTaskDelayUntil)
 *
 * Sync mechanisms
 *   Queue (len 1, overwrite)  : Sensor -> Display (latest reading)
 *   Task notification         : Sensor/ISR -> Alarm (critical event)
 *   Mutex (dataMutex)         : shared SensorData struct
 *   Mutex (serialMutex)       : Serial port shared by all tasks
 */

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

// ---------------- Pin configuration ----------------
#define DHT_PIN     15
#define DHT_TYPE    DHT22
#define BUZZER_PIN  18
#define LED_PIN     19
#define BUTTON_PIN  4      // active LOW, internal pull-up
#define OLED_SDA    21
#define OLED_SCL    22

// ---------------- Thresholds / timing ----------------
#define TEMP_ALARM_ON    40.0f   // deg C : alarm ON  above this
#define TEMP_ALARM_OFF   38.0f   // deg C : alarm OFF below this (hysteresis)
#define SENSOR_PERIOD_MS 500
#define DISPLAY_PERIOD_MS 1000

// ---------------- Types ----------------
struct SensorData {
  float temperature;
  float humidity;
  uint32_t timestampMs;
  bool valid;
};

// ---------------- RTOS handles ----------------
static QueueHandle_t     displayQueue;
static SemaphoreHandle_t dataMutex;
static SemaphoreHandle_t serialMutex;
static TaskHandle_t      alarmTaskHandle;

// ---------------- Shared resources ----------------
static SensorData sharedData = {0, 0, 0, false};   // protected by dataMutex
static volatile bool alarmActive = false;

static DHT dht(DHT_PIN, DHT_TYPE);
static Adafruit_SSD1306 oled(128, 64, &Wire, -1);

// Notification bit flags
#define NOTIFY_OVER_TEMP  (1UL << 0)
#define NOTIFY_BUTTON     (1UL << 1)

// ---------------- Thread-safe logging ----------------
static void logf(const char *fmt, ...) {
  char buf[128];
  va_list args;
  va_start(args, fmt);
  vsnprintf(buf, sizeof(buf), fmt, args);
  va_end(args);
  if (xSemaphoreTake(serialMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    Serial.print(buf);
    xSemaphoreGive(serialMutex);
  }
}

// ---------------- Button ISR -> Alarm task ----------------
static void IRAM_ATTR buttonISR() {
  BaseType_t woken = pdFALSE;
  xTaskNotifyFromISR(alarmTaskHandle, NOTIFY_BUTTON, eSetBits, &woken);
  portYIELD_FROM_ISR(woken);
}

// =====================================================
// Task 1: Sensor acquisition (periodic, 500 ms)
// =====================================================
static void SensorTask(void *pv) {
  TickType_t lastWake = xTaskGetTickCount();
  for (;;) {
    SensorData s;
    s.temperature = dht.readTemperature();
    s.humidity    = dht.readHumidity();
    s.timestampMs = millis();
    s.valid       = !(isnan(s.temperature) || isnan(s.humidity));

    if (s.valid) {
      // 1) update shared struct (mutex protected)
      if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
        sharedData = s;
        xSemaphoreGive(dataMutex);
      }
      // 2) push latest sample to display (never blocks: overwrite)
      xQueueOverwrite(displayQueue, &s);

      // 3) critical condition -> notify alarm task immediately
      if (s.temperature > TEMP_ALARM_ON) {
        xTaskNotify(alarmTaskHandle, NOTIFY_OVER_TEMP, eSetBits);
      }
      logf("[SENSOR ] t=%lu ms  T=%.1fC  H=%.1f%%\n",
           s.timestampMs, s.temperature, s.humidity);
    } else {
      logf("[SENSOR ] read failed\n");
    }
    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(SENSOR_PERIOD_MS));
  }
}

// =====================================================
// Task 2: Display update (periodic, 1000 ms)
// =====================================================
static void DisplayTask(void *pv) {
  TickType_t lastWake = xTaskGetTickCount();
  SensorData s = {0, 0, 0, false};
  for (;;) {
    // take newest reading if available, otherwise keep the last one (no blocking)
    xQueueReceive(displayQueue, &s, 0);

    oled.clearDisplay();
    oled.setTextColor(SSD1306_WHITE);
    oled.setTextSize(1);
    oled.setCursor(0, 0);
    oled.println("RTOS Scheduler");
    oled.drawLine(0, 10, 127, 10, SSD1306_WHITE);

    if (s.valid) {
      oled.setCursor(0, 16);
      oled.setTextSize(2);
      oled.printf("T:%.1fC", s.temperature);
      oled.setCursor(0, 36);
      oled.setTextSize(1);
      oled.printf("Humidity: %.1f %%", s.humidity);
    } else {
      oled.setCursor(0, 20);
      oled.println("Waiting for sensor...");
    }

    oled.setCursor(0, 52);
    oled.setTextSize(1);
    oled.print(alarmActive ? "!! ALARM ACTIVE !!" : "Status: NORMAL");
    oled.display();

    logf("[DISPLAY] updated  alarm=%s\n", alarmActive ? "ON" : "OFF");
    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(DISPLAY_PERIOD_MS));
  }
}

// =====================================================
// Task 3: Emergency alarm (event driven, highest priority)
// =====================================================
static void AlarmTask(void *pv) {
  for (;;) {
    uint32_t bits = 0;
    // Sleep until an event arrives, or wake every 200 ms to check for clear condition
    BaseType_t got = xTaskNotifyWait(0, 0xFFFFFFFF, &bits, pdMS_TO_TICKS(200));

    if (got == pdTRUE) {
      if (bits & NOTIFY_OVER_TEMP) {
        if (!alarmActive) logf("[ALARM  ] !!! OVER-TEMPERATURE at t=%lu ms\n", millis());
        alarmActive = true;
      }
      if (bits & NOTIFY_BUTTON) {
        logf("[ALARM  ] !!! MANUAL EMERGENCY (button) at t=%lu ms\n", millis());
        alarmActive = true;
      }
    } else if (alarmActive) {
      // timeout: check if the situation is back to normal (hysteresis)
      float t = 0;
      bool ok = false;
      if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
        t = sharedData.temperature;
        ok = sharedData.valid;
        xSemaphoreGive(dataMutex);
      }
      if (ok && t < TEMP_ALARM_OFF && digitalRead(BUTTON_PIN) == HIGH) {
        alarmActive = false;
        logf("[ALARM  ] cleared, T=%.1fC\n", t);
      }
    }

    // drive outputs
    digitalWrite(LED_PIN, alarmActive ? HIGH : LOW);
    if (alarmActive) {
      tone(BUZZER_PIN, 2000);
    } else {
      noTone(BUZZER_PIN);
    }
  }
}

// =====================================================
// Setup
// =====================================================
void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  Wire.begin(OLED_SDA, OLED_SCL);
  if (!oled.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED init failed");
    for (;;) delay(1000);
  }
  dht.begin();

  // RTOS objects
  displayQueue = xQueueCreate(1, sizeof(SensorData));
  dataMutex    = xSemaphoreCreateMutex();
  serialMutex  = xSemaphoreCreateMutex();
  configASSERT(displayQueue && dataMutex && serialMutex);

  // Tasks (pinned to core 1; stack in bytes on ESP32)
  xTaskCreatePinnedToCore(AlarmTask,   "AlarmTask",   3072, NULL, 3, &alarmTaskHandle, 1);
  xTaskCreatePinnedToCore(SensorTask,  "SensorTask",  3072, NULL, 2, NULL,             1);
  xTaskCreatePinnedToCore(DisplayTask, "DisplayTask", 4096, NULL, 1, NULL,             1);

  attachInterrupt(digitalPinToInterrupt(BUTTON_PIN), buttonISR, FALLING);

  logf("[SYSTEM ] Scheduler started: Alarm(p3) Sensor(p2) Display(p1)\n");
}

// loopTask is not needed; delete it so it doesn't compete for the CPU
void loop() {
  vTaskDelete(NULL);
}
